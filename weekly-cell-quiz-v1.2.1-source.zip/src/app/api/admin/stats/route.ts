import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";
export async function GET(){
 try{
  await requireAdmin();
  const quizzes=await supabaseRest<Array<{id:string;title:string;status:string}>>("quizzes?quiz_type=eq.WEEKLY&order=open_at.desc&limit=1&select=id,title,status");
  const quiz=quizzes[0]??null;if(!quiz)return NextResponse.json({quiz:null,participation:0,average:null,questions:[],people:[]});
  const subs=await supabaseRest<Array<{id:string;person_id:string;group_id_snapshot:string|null;score:number;submitted_at:string}>>(`submissions?quiz_id=eq.${quiz.id}&mode=eq.OFFICIAL&order=submitted_at.asc&select=id,person_id,group_id_snapshot,score,submitted_at`);
  const ids=subs.map(s=>s.id);const personIds=[...new Set(subs.map(s=>s.person_id))];const groupIds=[...new Set(subs.map(s=>s.group_id_snapshot).filter(Boolean))] as string[];
  const [questions,people,groups]=await Promise.all([
    supabaseRest<Array<{id:string;prompt:string;sort_order:number}>>(`questions?quiz_id=eq.${quiz.id}&selected=eq.true&order=sort_order.asc&select=id,prompt,sort_order`),
    personIds.length?supabaseRest<Array<{id:string;display_name:string}>>(`people?id=in.(${personIds.join(",")})&select=id,display_name`):Promise.resolve([]),
    groupIds.length?supabaseRest<Array<{id:string;name:string}>>(`groups?id=in.(${groupIds.join(",")})&select=id,name`):Promise.resolve([])
  ]);
  const answers=ids.length?await supabaseRest<Array<{question_id:string;is_correct:boolean}>>(`answers?submission_id=in.(${ids.join(",")})&select=question_id,is_correct`):[];
  const qstats=questions.map(q=>{const rows=answers.filter(a=>a.question_id===q.id);const correct=rows.filter(a=>a.is_correct).length;return {id:q.id,prompt:q.prompt,total:rows.length,correct,rate:rows.length?Math.round(correct/rows.length*100):null};});
  const names=new Map(people.map(p=>[p.id,p.display_name]));const groupNames=new Map(groups.map(g=>[g.id,g.name]));
  const detail=subs.map(s=>({personId:s.person_id,name:names.get(s.person_id)??"알 수 없음",groupId:s.group_id_snapshot,groupName:s.group_id_snapshot?groupNames.get(s.group_id_snapshot)??"과거 셀":"셀 없음",score:s.score,submittedAt:s.submitted_at}));
  const avg=subs.length?Math.round(subs.reduce((sum,x)=>sum+x.score,0)/subs.length):null;
  return NextResponse.json({quiz,participation:subs.length,average:avg,questions:qstats,people:detail});
 }catch(error){const message=error instanceof Error?error.message:"통계를 불러오지 못했습니다.";return NextResponse.json({error:message},{status:message==="ADMIN_REQUIRED"?403:500});}
}
