"use client";
import { useEffect, useState } from "react";
import { ParticipantSelect } from "@/components/ParticipantSelect"; import { HomeScreen } from "@/components/HomeScreen"; import { QuizIntro } from "@/components/QuizIntro"; import { QuizQuestion } from "@/components/QuizQuestion"; import { ResultScreen } from "@/components/ResultScreen"; import { AnswerReview } from "@/components/AnswerReview"; import { ConfirmModal } from "@/components/ConfirmModal"; import { MyStatsScreen } from "@/components/MyStatsScreen"; import { ArchiveScreen } from "@/components/ArchiveScreen"; import { SpecialScreen } from "@/components/SpecialScreen"; import { WeeklyResultScreen } from "@/components/WeeklyResultScreen"; import { MonthlyResultScreen } from "@/components/MonthlyResultScreen"; import { SettingsScreen } from "@/components/SettingsScreen"; import { Brand } from "@/components/Brand"; import { useQuizApp } from "@/state/useQuizApp"; import { groupDisplayName } from "@/domain/display"; import type { Person } from "@/domain/types";
export default function Page(){
 const app=useQuizApp();const[personCandidate,setPersonCandidate]=useState<Person|null>(null);const[submitOpen,setSubmitOpen]=useState(false);const[homeConfirm,setHomeConfirm]=useState(false);
 useEffect(()=>{const handler=()=>{if(app.person&&app.screen!=="home"&&app.screen!=="select")app.goHome();};window.addEventListener("popstate",handler);return()=>window.removeEventListener("popstate",handler);},[app.person,app.screen]);
 useEffect(()=>{if(typeof window==="undefined")return;if(app.screen!=="home"&&app.screen!=="select"&&history.state?.wcqScreen!==app.screen)history.pushState({wcqScreen:app.screen},"");},[app.screen]);
 if(!app.hydrated)return <main className="appShell"><div className="loading">말씀을 준비하고 있어요…</div></main>;
 const goStartOrResult=()=>{app.setError(null);app.setScreen(app.weeklyResult?"result":"intro")};
 const changeUser=()=>{app.setError(null);app.setPerson(null);app.setScreen("select");};
 const requestHome=()=>{if(app.screen==="quiz")setHomeConfirm(true);else{app.setError(null);app.goHome();}};
 const startCurrent=()=>void app.startQuiz(app.playKind==="PRACTICE"?"PRACTICE":"OFFICIAL",app.playKind==="WEEKLY"?undefined:{id:app.quiz.id,title:app.quiz.title,subtitle:app.quiz.subtitle,bibleRange:app.quiz.bibleRange,lifeDateRange:app.quiz.lifeDateRange,kind:app.playKind});
 const introError=app.error&&app.screen==="intro";
 return <main className="appShell" aria-live="polite">
 <Brand onHome={app.person?requestHome:undefined}/>
 {!introError&&app.error&&<div className="errorBanner"><span>{app.error}</span><button onClick={()=>app.setError(null)}>닫기</button></div>}
 {app.screen==="select"&&<ParticipantSelect groups={app.groups} groupId={app.groupId} onGroup={app.setGroupId} onPerson={setPersonCandidate}/>} 
 {app.screen==="home"&&app.person&&<HomeScreen person={app.person} group={app.group} quiz={app.weeklyQuiz} result={app.weeklyResult} monthlyRanking={app.monthlyRanking} specialCount={app.specials.length} onStart={goStartOrResult} onReview={()=>app.reviewAllowed&&app.setScreen("review")} onStats={()=>app.setScreen("stats")} onArchive={()=>app.setScreen("archive")} onSpecial={()=>app.setScreen("special")} onWeeklyResult={()=>app.setScreen("weekly-result")} onMonthlyResult={()=>app.setScreen("monthly-result")} onSettings={()=>{app.setError(null);app.setScreen("settings")}}/>}
 {app.screen==="weekly-result"&&<WeeklyResultScreen weekly={app.weeklyRanking} monthly={app.monthlyRanking} onBack={app.goHome}/>} 
 {app.screen==="monthly-result"&&<MonthlyResultScreen monthly={app.monthlyRanking} weekly={app.weeklyRanking} onBack={app.goHome}/>} 
 {app.screen==="stats"&&<MyStatsScreen data={app.stats} onBack={app.goHome}/>} 
 {app.screen==="archive"&&<ArchiveScreen items={app.archive} onBack={app.goHome} onPractice={(id)=>{const item=app.archive.find((x:any)=>x.quizId===id);if(item)void app.startArchivedPractice(item);}}/>}
 {app.screen==="special"&&<SpecialScreen specials={app.specials} onBack={app.goHome} onStart={(id)=>{const s=app.specials.find((x:any)=>x.quizId===id);if(s)void app.startSpecial(s);}}/>}
 {app.screen==="settings"&&app.person&&<SettingsScreen person={app.person} group={app.group} onBack={()=>{app.setError(null);app.goHome()}} onChangeUser={changeUser}/>} 
 {app.screen==="intro"&&<QuizIntro quiz={app.quiz} onBack={app.goHome} onStart={startCurrent}/>} 
 {app.screen==="quiz"&&app.question&&<QuizQuestion questions={app.quiz.questions} question={app.question} questionIndex={app.questionIndex} answers={app.answers} answeredCount={app.answeredCount} onBack={()=>setHomeConfirm(true)} onQuestion={app.setQuestionIndex} onAnswer={app.answer} onPrev={()=>app.setQuestionIndex(Math.max(0,app.questionIndex-1))} onNext={()=>app.setQuestionIndex(Math.min(app.quiz.questions.length-1,app.questionIndex+1))} onSubmit={()=>setSubmitOpen(true)}/>} 
 {app.screen==="result"&&app.person&&app.result&&<ResultScreen person={app.person} result={app.result} weeklyRanking={app.playKind==="WEEKLY"?app.weeklyRanking:null} monthlyRanking={app.playKind==="WEEKLY"?app.monthlyRanking:null} reviewAvailable={app.reviewAllowed} reviewMessage={app.reviewMessage} onReview={()=>app.setScreen("review")} onHome={app.goHome}/>} 
 {app.specialResult&&app.screen==="result"&&<div className="card section specialResultBanner"><strong>{app.specialResult.passed?"PASS":"이번 도전 완료"}</strong><span>{app.specialResult.passed&&app.specialResult.issuePass?"입장권이 발급되었습니다.":`통과 기준 ${app.specialResult.passScore}점`}</span></div>}
 {app.screen==="review"&&app.result&&app.reviewAllowed&&<AnswerReview questions={app.reviewQuestions} answers={app.answers} result={app.result} onBack={()=>app.setScreen("result")} onHome={app.goHome}/>} 
 {app.busy&&<div className="busyOverlay"><div className="busyCard">처리하고 있어요…</div></div>}
 {personCandidate&&<ConfirmModal title={`${personCandidate.name}님 맞으신가요?`} body={`${personCandidate.name}님으로 이번 주 기록이 저장됩니다. · ${groupDisplayName(app.group.name)}`} cancelLabel="아니에요" confirmLabel="맞아요" onCancel={()=>setPersonCandidate(null)} onConfirm={()=>{app.setError(null);app.setPerson(personCandidate);setPersonCandidate(null);app.setScreen("home");}}/>}
 {submitOpen&&app.person&&<ConfirmModal title={app.missing.length?"아직 답하지 않은 문제가 있어요":"이대로 제출할까요?"} body={`${app.person.name}님의 ${app.playKind==="PRACTICE"?"연습":"이번 기록"}으로 저장됩니다.`} cancelLabel={app.missing.length?"문제로 돌아가기":"돌아가기"} confirmLabel={app.missing.length?"그래도 제출":"제출하기"} onCancel={()=>setSubmitOpen(false)} onConfirm={()=>{setSubmitOpen(false);void app.submit();}}>{app.missing.length>0&&<div className="missing">{app.missing.map((i)=><span key={i}>{i+1}번</span>)}</div>}</ConfirmModal>}
 {homeConfirm&&<ConfirmModal title="퀴즈를 나갈까요?" body="지금까지 선택한 답은 이 기기에 자동 저장됩니다. 홈으로 나가도 다시 이어서 풀 수 있어요." cancelLabel="계속 풀기" confirmLabel="홈으로 나가기" onCancel={()=>setHomeConfirm(false)} onConfirm={()=>{setHomeConfirm(false);app.goHome();}}/>}
 {introError&&<ConfirmModal title="퀴즈를 시작할 수 없어요" body={app.error??"퀴즈를 시작하지 못했습니다."} cancelLabel="닫기" confirmLabel="홈으로" onCancel={()=>app.setError(null)} onConfirm={()=>{app.setError(null);app.goHome();}}/>}
 </main>;
}
