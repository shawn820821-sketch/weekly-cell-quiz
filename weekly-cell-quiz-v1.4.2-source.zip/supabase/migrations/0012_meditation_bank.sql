create table if not exists public.meditation_messages (
  id uuid primary key default gen_random_uuid(),
  month_key text not null check (month_key ~ '^20[0-9]{2}-(0[1-9]|1[0-2])$'),
  sort_order integer not null default 0,
  title text not null,
  message_text text not null,
  bible_reference text,
  source text,
  message_type text,
  import_id uuid references public.content_imports(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists meditation_messages_month_idx on public.meditation_messages(month_key,active,sort_order);
alter table public.meditation_messages enable row level security;
