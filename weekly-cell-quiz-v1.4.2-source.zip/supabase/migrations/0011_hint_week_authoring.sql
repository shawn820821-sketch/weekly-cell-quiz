alter table public.questions add column if not exists hint text;
alter table public.answers add column if not exists hint_used boolean not null default false;
alter table public.quizzes add column if not exists content_month_key text;
alter table public.quizzes add column if not exists content_week_index integer;
alter table public.quizzes add column if not exists import_id uuid references public.content_imports(id);
alter table public.quizzes drop constraint if exists quizzes_content_week_index_check;
alter table public.quizzes add constraint quizzes_content_week_index_check check (content_week_index is null or content_week_index between 1 and 6);
create index if not exists quizzes_authoring_week_idx on public.quizzes(quiz_type,content_month_key,content_week_index,open_at);
