-- v1.2.1 usability hardening

-- Active seasons may have no known end date yet.
alter table public.seasons alter column ends_on drop not null;
alter table public.seasons drop constraint if exists seasons_check;
alter table public.seasons add constraint seasons_check check (ends_on is null or ends_on >= starts_on);

-- Remove accidental duplicate open-ended operator roles, keeping one deterministic row.
with ranked as (
  select id,
         row_number() over (
           partition by person_id, role
           order by starts_on asc, id asc
         ) as rn
  from public.roles
  where ends_on is null and role in ('LEADER','ADMIN')
)
delete from public.roles r
using ranked x
where r.id=x.id and x.rn>1;

-- A person may have at most one currently open-ended assignment per operator role.
create unique index if not exists roles_one_open_assignment_per_role
  on public.roles(person_id, role)
  where ends_on is null and role in ('LEADER','ADMIN');
