export function groupDisplayName(name:string){
  const value=(name||"").trim();
  if(!value)return "소속 없음";
  if(value==="기타" || value.endsWith("셀") || value.endsWith("님의 셀"))return value;
  return `${value}님의 셀`;
}
