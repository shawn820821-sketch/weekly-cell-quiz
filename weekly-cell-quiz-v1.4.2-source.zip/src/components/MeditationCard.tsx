import type { MeditationMessage } from "@/domain/types";

export function MeditationCard({ message, label = "지난 말씀 돌아보기", compact = false }: { message?: MeditationMessage | null; label?: string; compact?: boolean }) {
  if (!message) return null;
  return <section className={compact ? "meditationCard compact" : "meditationCard"}>
    <div className="meditationLabel">{label}</div>
    <h3>{message.title}</h3>
    <p>{message.text}</p>
    {(message.bibleReference || message.source) && <div className="meditationMeta">{message.bibleReference && <span>{message.bibleReference}</span>}{message.source && <span>{message.source}</span>}</div>}
  </section>;
}
