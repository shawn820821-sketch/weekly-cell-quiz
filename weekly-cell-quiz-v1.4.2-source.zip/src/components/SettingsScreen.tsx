import type { Group, Person } from "@/domain/types";
import { groupDisplayName } from "@/domain/display";
export function SettingsScreen({person,group,onBack,onChangeUser}:{person:Person;group:Group;onBack:()=>void;onChangeUser:()=>void}){return <><div className="screenHeader"><button className="back" onClick={onBack}>←</button><div><small>SETTINGS</small><h1>설정</h1></div></div>
<section className="section card"><div className="eyebrow">내 정보</div><h2>{person.name}</h2><p className="subtle">{groupDisplayName(group.name)}</p><button className="btn btnSecondary full" onClick={onChangeUser}>사용자 변경</button></section>
<section className="section card guideCard"><div className="eyebrow">이용 안내</div><ul><li>주간 퀴즈는 매주 월요일 00:00부터 토요일 23:59까지 참여할 수 있어요.</li><li>첫 공식 제출만 주간·월간 기록에 반영됩니다.</li><li>한 번 제출한 뒤 다시 풀기는 연습 모드이며 공식 기록을 바꾸지 않아요.</li><li>마감 전에 시작했다면 마감 시간이 지나도 시작한 퀴즈는 끝까지 제출할 수 있어요.</li><li>정답 공개가 허용된 퀴즈는 제출 뒤 해설과 말씀 근거를 다시 볼 수 있어요.</li></ul></section>
<section className="section card operatorEntry"><div><div className="eyebrow">운영</div><h3>운영자 모드</h3><p className="subtle">리더·관리자는 본인 이름과 4자리 PIN으로 들어갑니다.</p></div><a className="btn btnPrimary" href="/operator">운영자 모드 →</a></section>
<section className="section card"><div className="eyebrow">정보</div><p className="subtle">주간 셀 퀴즈 · v1.4</p></section></>};
