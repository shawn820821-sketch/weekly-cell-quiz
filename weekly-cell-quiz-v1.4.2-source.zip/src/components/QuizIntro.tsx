import type { MeditationMessage, QuizDefinition } from "@/domain/types";
import { MeditationCard } from "@/components/MeditationCard";
export function QuizIntro({ quiz, meditation, onBack, onStart }: { quiz: QuizDefinition; meditation?: MeditationMessage | null; onBack: () => void; onStart: () => void }) {
  const count = quiz.publishedQuestionCount ?? quiz.questions.length;
  return <><div className="topbar"><button className="back" onClick={onBack}>‹</button><strong>이번 주 퀴즈</strong><span /></div>
  <section className="questionScene introScene"><div className="introHeading"><div className="eyebrow">{quiz.subtitle}</div><h1 className="question introTitle">{quiz.title}</h1><div className="introSource"><span>{quiz.lifeDateRange||"이번 주 생명의삶"}</span><strong>{quiz.bibleRange||"말씀 범위"}</strong></div></div>
  <div className="card translucent introGuide"><p><strong>{count || "–"}문제 · 지난주 말씀 돌아보기</strong></p><p>정답을 맞히는 것보다 말씀을 다시 떠올리는 시간이 더 중요해요. 기억나는 장면과 사람, 말씀의 흐름을 천천히 생각하면서 풀어보세요.</p></div>
  <MeditationCard message={meditation} label="퀴즈 전 묵상" compact/>
  <button className="btn btnPrimary full" onClick={onStart}>시작하기 →</button></section></>;
}
