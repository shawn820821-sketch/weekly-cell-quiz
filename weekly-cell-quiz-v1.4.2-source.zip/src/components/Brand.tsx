"use client";
export function Brand({onHome,href="/",compact=false}:{onHome?:()=>void;href?:string;compact?:boolean}) {
  const content=<><div><div className="brandMark">주간 셀 퀴즈</div>{!compact&&<small>GOD&apos;S WORD, OUR DAILY LIFE</small>}</div></>;
  return <div className={`brand ${compact?"compact":""}`}>{onHome?<button className="brandHome" onClick={onHome} aria-label="주간 셀 퀴즈 홈으로">{content}</button>:<a className="brandHome" href={href} aria-label="주간 셀 퀴즈 홈으로">{content}</a>}</div>;
}
