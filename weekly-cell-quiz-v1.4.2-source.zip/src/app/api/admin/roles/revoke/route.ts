import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";

type RoleRow={id:string;person_id:string;role:"LEADER"|"ADMIN";starts_on:string;ends_on:string|null};

export async function POST(request:Request){
 try{
  await requireAdmin();
  const {roleId,personId,role,effectiveDate}=await request.json() as {roleId?:string;personId:string;role:"LEADER"|"ADMIN";effectiveDate:string};
  if(!roleId||!personId||!role||!effectiveDate)return NextResponse.json({error:"해제 정보를 확인해주세요."},{status:400});
  const rows=await supabaseRest<RoleRow[]>(`roles?id=eq.${roleId}&person_id=eq.${personId}&role=eq.${role}&limit=1&select=id,person_id,role,starts_on,ends_on`);
  const target=rows[0];
  if(!target)return NextResponse.json({error:"해제할 권한을 찾을 수 없습니다."},{status:404});
  if(role==="ADMIN"){
    const today=new Date().toISOString().slice(0,10);
    const active=await supabaseRest<Array<{id:string;person_id:string}>>(`roles?role=eq.ADMIN&starts_on=lte.${today}&or=(ends_on.is.null,ends_on.gte.${today})&select=id,person_id`);
    const other=active.filter(r=>r.id!==roleId);
    if(other.length===0)return NextResponse.json({error:"마지막 관리자 권한은 해제할 수 없습니다. 새 관리자를 먼저 지정해주세요."},{status:409});
  }
  if(target.starts_on>=effectiveDate){
    await supabaseRest(`roles?id=eq.${roleId}`,{method:"DELETE"});
  }else{
    const dayBefore=new Date(`${effectiveDate}T00:00:00Z`);dayBefore.setUTCDate(dayBefore.getUTCDate()-1);
    await supabaseRest(`roles?id=eq.${roleId}`,{method:"PATCH",body:JSON.stringify({ends_on:dayBefore.toISOString().slice(0,10)})});
  }
  return NextResponse.json({ok:true});
 }catch(e){const m=e instanceof Error?e.message:"권한 해제 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:400});}
}
