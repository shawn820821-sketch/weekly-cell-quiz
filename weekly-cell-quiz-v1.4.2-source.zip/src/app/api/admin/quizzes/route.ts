import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";

export async function GET() {
  try { await requireAdmin(); const [quizzes,questions]=await Promise.all([supabaseRest<any[]>("quizzes?order=open_at.asc.nullslast,created_at.desc&select=*"),supabaseRest<Array<{quiz_id:string;selected:boolean}>>("questions?select=quiz_id,selected")]);const counts=new Map<string,{candidateCount:number;selectedCount:number}>();for(const q of questions){const c=counts.get(q.quiz_id)??{candidateCount:0,selectedCount:0};c.candidateCount++;if(q.selected)c.selectedCount++;counts.set(q.quiz_id,c);}return NextResponse.json({ quizzes: quizzes.map(q=>({...q,...(counts.get(q.id)??{candidateCount:0,selectedCount:0})})) }); }
  catch (error) { const m = error instanceof Error ? error.message : "오류"; return NextResponse.json({ error:m }, { status:m === "ADMIN_REQUIRED" ? 403 : 500 }); }
}

export async function POST(request: Request) {
  try {
    const admin = await requireAdmin();
    const body = await request.json();
    const quiz = await supabaseRest("quizzes", { method: "POST", body: JSON.stringify({ title: body.title, subtitle: body.subtitle ?? null, quiz_type: body.quizType ?? "WEEKLY", status: "DRAFT", selection_mode: body.selectionMode ?? "FIXED", random_question_count: body.selectionMode === "RANDOM" ? Number(body.randomQuestionCount ?? 10) : null, published_question_count: Number(body.publishedQuestionCount ?? 10), life_date_range: body.lifeDateRange ?? null, bible_range: body.bibleRange ?? null, open_at: body.openAt ?? null, close_at: body.closeAt ?? null, created_by: admin.personId }) });
    return NextResponse.json({ quiz }, { status: 201 });
  } catch (error) { const m = error instanceof Error ? error.message : "Quiz 생성 실패"; return NextResponse.json({ error:m }, { status:m === "ADMIN_REQUIRED" ? 403 : 500 }); }
}
