import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";
export async function POST(request:Request){
 try{await requireAdmin();const {quizId,status}=await request.json() as {quizId?:string;status?:"DRAFT"|"SCHEDULED"|"OPEN"|"CLOSED"};if(!quizId||!status)return NextResponse.json({error:"퀴즈 상태를 확인해주세요."},{status:400});await supabaseRest(`quizzes?id=eq.${quizId}`,{method:"PATCH",body:JSON.stringify({status})});return NextResponse.json({ok:true,status});}catch(e){const m=e instanceof Error?e.message:"상태 변경 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:500});}
}
