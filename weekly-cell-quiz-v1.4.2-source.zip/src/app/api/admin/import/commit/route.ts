import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";

type Q={no:number;questionType:"MCQ"|"OX";prompt:string;choices:string[];correctAnswer:string;explanation:string;bibleRange:string;difficulty:string;note:string;hint?:string};
type Week={sheetName:string;quizType?:"WEEKLY"|"SPECIAL";title:string;lifeDateRange:string;bibleRange:string;openAt:string;closeAt:string;questions:Q[];errors:string[]};
type Meditation={no:number;title:string;text:string;bibleReference?:string;source?:string;messageType?:string};
type ExistingImport={id:string;source_name:string;month_key:string|null};
type ExistingQuiz={id:string;status:string;quiz_type:"WEEKLY"|"SPECIAL";content_week_index:number|null;title:string;life_date_range:string|null};

function monthFromName(name:string){
 const m=name.match(/(20\d{2})[-_.년 ]?(1[0-2]|0?[1-9])(?=\D|$)/);return m?`${m[1]}-${String(Number(m[2])).padStart(2,"0")}`:null;
}
function weekIndex(sheetName:string){return Number(sheetName.match(/^(\d+)주차$/)?.[1]||0)||null;}
function sameProtectedWeek(w:Week,q:ExistingQuiz){
 const wi=weekIndex(w.sheetName);
 if(wi&&q.content_week_index===wi)return true;
 if(w.title.trim()===q.title.trim())return true;
 // 말씀 기간만 같은 것은 같은 Quiz 주차로 보지 않는다. 과거 주차 보정 시 같은 본문이 다음 주 Quiz로 이월될 수 있다.
 return false;
}

export async function POST(request:Request){
 try{
  const admin=await requireAdmin();
  const body=await request.json() as {fileName:string;sourceHash:string;monthKey?:string;mode:"NEW"|"REPLACE";replaceImportId?:string|null;weeks:Week[];meditations?:Meditation[];meditationErrors?:string[]};
  if(!body.fileName||!body.sourceHash||!body.weeks?.length)return NextResponse.json({error:"Import 데이터가 부족합니다."},{status:400});
  if(body.weeks.some(w=>w.errors.some(e=>!e.includes("권장")))||(body.meditationErrors??[]).length)return NextResponse.json({error:"오류가 있는 파일은 등록할 수 없습니다."},{status:400});

  const datedWeek=body.weeks.find(w=>w.quizType!=="SPECIAL"&&w.openAt&&!Number.isNaN(new Date(w.openAt).getTime()));
  const datedMonth=datedWeek?`${new Date(datedWeek.openAt).getFullYear()}-${String(new Date(datedWeek.openAt).getMonth()+1).padStart(2,"0")}`:null;
  const inferredMonthKey=body.monthKey||monthFromName(body.fileName)||datedMonth;
  if((body.meditations??[]).length&&!inferredMonthKey)return NextResponse.json({error:"묵상메시지 Bank를 저장하려면 파일명에 YYYY-MM 월 정보가 필요합니다."},{status:400});

  // 같은 달 파일은 미공개 DRAFT만 자동 교체한다. 이미 예약/공개/마감된 퀴즈와 제출 기록은 보존한다.
  const protectedQuizzes:ExistingQuiz[]=[];
  let replacedDraftCount=0;
  const matchedImportIds=new Set<string>();

  if(inferredMonthKey){
    const imports=await supabaseRest<ExistingImport[]>("content_imports?status=eq.COMMITTED&select=id,source_name,month_key");
    for(const imp of imports){if(imp.month_key===inferredMonthKey||monthFromName(imp.source_name)===inferredMonthKey)matchedImportIds.add(imp.id);}
    if(body.mode==="REPLACE"&&body.replaceImportId)matchedImportIds.add(body.replaceImportId);

    const quizIds=new Set<string>();
    if(matchedImportIds.size){
      const qs=await supabaseRest<Array<{quiz_id:string}>>(`questions?import_id=in.(${[...matchedImportIds].join(",")})&select=quiz_id`);
      qs.forEach(x=>quizIds.add(x.quiz_id));
    }
    const tagged=await supabaseRest<Array<{id:string}>>(`quizzes?quiz_type=eq.WEEKLY&content_month_key=eq.${inferredMonthKey}&select=id`);
    tagged.forEach(x=>quizIds.add(x.id));

    if(quizIds.size){
      const existing=await supabaseRest<ExistingQuiz[]>(`quizzes?id=in.(${[...quizIds].join(",")})&select=id,status,quiz_type,content_week_index,title,life_date_range`);
      const drafts=existing.filter(q=>q.status==="DRAFT").map(q=>q.id);
      protectedQuizzes.push(...existing.filter(q=>q.status!=="DRAFT"));
      if(drafts.length){await supabaseRest(`quizzes?id=in.(${drafts.join(",")})`,{method:"DELETE"});replacedDraftCount=drafts.length;}
    }

    // 구버전 Import는 month_key/import_id가 비어 있을 수 있다. 제목/말씀기간이 같은 기존 퀴즈도 함께 보호/교체한다.
    const allWeekly=await supabaseRest<ExistingQuiz[]>("quizzes?quiz_type=eq.WEEKLY&select=id,status,quiz_type,content_week_index,title,life_date_range");
    const alreadyHandled=new Set([...protectedQuizzes.map(q=>q.id)]);
    const matchingLegacy=allWeekly.filter(q=>!alreadyHandled.has(q.id)&&body.weeks.some(w=>(w.quizType??"WEEKLY")==="WEEKLY"&&sameProtectedWeek(w,q)));
    const legacyDrafts=matchingLegacy.filter(q=>q.status==="DRAFT").map(q=>q.id);
    protectedQuizzes.push(...matchingLegacy.filter(q=>q.status!=="DRAFT"));
    if(legacyDrafts.length){await supabaseRest(`quizzes?id=in.(${legacyDrafts.join(",")})`,{method:"DELETE"});replacedDraftCount+=legacyDrafts.length;}

    // 묵상 Bank는 월 단위 단일 원본이므로 같은 달 콘텐츠를 새 파일 기준으로 통째로 교체한다.
    if((body.meditations??[]).length)await supabaseRest(`meditation_messages?month_key=eq.${inferredMonthKey}`,{method:"DELETE"});
  }

  const imports=await supabaseRest<Array<{id:string}>>("content_imports?select=id",{method:"POST",headers:{Prefer:"return=representation"},body:JSON.stringify({source_name:body.fileName,source_hash:body.sourceHash,month_key:inferredMonthKey,mode:matchedImportIds.size?"REPLACE":body.mode,replaces_import_id:body.replaceImportId||null,status:"COMMITTED",created_by:admin.personId,summary:{weeks:body.weeks.length,questions:body.weeks.reduce((n,w)=>n+w.questions.length,0),meditations:(body.meditations??[]).length,replacedDrafts:replacedDraftCount}})});
  const importId=imports[0]?.id;if(!importId)throw new Error("Import 기록 생성에 실패했습니다.");
  const createdQuizIds:string[]=[]; const skippedProtectedWeeks:string[]=[];

  for(const w of body.weeks.filter(w=>w.questions.length)){
    const qt=w.quizType??"WEEKLY";
    if(qt==="WEEKLY"&&protectedQuizzes.some(q=>q.quiz_type==="WEEKLY"&&sameProtectedWeek(w,q))){skippedProtectedWeeks.push(w.sheetName);continue;}
    const wi=qt==="SPECIAL"?null:weekIndex(w.sheetName);
    const qs=await supabaseRest<Array<{id:string}>>("quizzes?select=id",{method:"POST",headers:{Prefer:"return=representation"},body:JSON.stringify({title:w.title,quiz_type:qt,status:"DRAFT",life_date_range:w.lifeDateRange||null,bible_range:w.bibleRange||null,open_at:w.openAt||null,close_at:w.closeAt||null,selection_mode:"FIXED",content_month_key:inferredMonthKey,content_week_index:wi,import_id:importId})});
    const quizId=qs[0]?.id;if(!quizId)continue;createdQuizIds.push(quizId);
    const payload=w.questions.map((q,i)=>({quiz_id:quizId,sort_order:i+1,candidate_order:q.no||i+1,question_type:q.questionType,prompt:q.prompt,choices:q.choices,correct_index:q.questionType==="OX"?(q.correctAnswer==="O"?0:1):({A:0,B:1,C:2,D:3} as Record<string,number>)[q.correctAnswer],explanation:q.explanation,bible_range:q.bibleRange||null,difficulty:q.difficulty||"MEDIUM",note:q.note||null,hint:q.hint?.trim()||null,selected:false,import_id:importId}));
    await supabaseRest("questions",{method:"POST",body:JSON.stringify(payload)});
  }

  if((body.meditations??[]).length){
    const payload=(body.meditations??[]).map((m,i)=>({month_key:inferredMonthKey,sort_order:m.no||i+1,title:m.title,message_text:m.text,bible_reference:m.bibleReference||null,source:m.source||null,message_type:m.messageType||"요약·재작성(원문 직접 인용 아님)",import_id:importId}));
    await supabaseRest("meditation_messages",{method:"POST",body:JSON.stringify(payload)});
  }
  return NextResponse.json({ok:true,importId,createdQuizIds,meditationCount:(body.meditations??[]).length,replacedDraftCount,skippedProtectedWeeks});
 }catch(e){const m=e instanceof Error?e.message:"등록 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:500});}
}
