import { NextResponse } from "next/server";
import { requireAdmin } from "@/server/operatorAuth";
import { supabaseRest } from "@/lib/supabase/rest";

export async function GET(){try{await requireAdmin();return NextResponse.json({groups:await supabaseRest("groups?order=name.asc&select=id,name,active")});}catch(e){const m=e instanceof Error?e.message:"오류";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:500});}}
export async function POST(request:Request){try{await requireAdmin();const body=await request.json();const name=String(body.name??"").trim();if(!name)return NextResponse.json({error:"셀 이름을 입력해주세요."},{status:400});const group=await supabaseRest("groups",{method:"POST",body:JSON.stringify({name,active:true})});return NextResponse.json({group},{status:201});}catch(e){const m=e instanceof Error?e.message:"추가 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:500});}}
export async function PATCH(request:Request){try{await requireAdmin();const body=await request.json();if(!body.id)return NextResponse.json({error:"셀을 찾을 수 없습니다."},{status:400});const patch:any={};if(typeof body.name==="string")patch.name=body.name.trim();if(typeof body.active==="boolean")patch.active=body.active;const group=await supabaseRest(`groups?id=eq.${body.id}`,{method:"PATCH",body:JSON.stringify(patch)});return NextResponse.json({group});}catch(e){const m=e instanceof Error?e.message:"셀 수정 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:500});}}
export async function DELETE(request:Request){
 try{
  await requireAdmin();const u=new URL(request.url);const id=u.searchParams.get("id");if(!id)return NextResponse.json({error:"셀을 선택해주세요."},{status:400});
  const checks=await Promise.all([
   supabaseRest<Array<{person_id:string}>>(`group_memberships?group_id=eq.${id}&limit=1&select=person_id`),
   supabaseRest<Array<{id:string}>>(`roles?target_group_id=eq.${id}&limit=1&select=id`),
   supabaseRest<Array<{id:string}>>(`submissions?group_id_snapshot=eq.${id}&limit=1&select=id`),
   supabaseRest<Array<{id:string}>>(`quiz_sessions?group_id_snapshot=eq.${id}&limit=1&select=id`),
   supabaseRest<Array<{id:string}>>(`monthly_results?group_id=eq.${id}&limit=1&select=id`),
   supabaseRest<Array<{id:string}>>(`monthly_winners?group_id=eq.${id}&limit=1&select=id`),
  ]);
  if(checks.some(rows=>rows.length))return NextResponse.json({error:"소속 참가자나 기록이 연결된 셀은 삭제할 수 없습니다. 참가자를 먼저 이동하거나 셀을 비활성화해주세요."},{status:409});
  await supabaseRest(`groups?id=eq.${id}`,{method:"DELETE"});return NextResponse.json({ok:true});
 }catch(e){const m=e instanceof Error?e.message:"셀 삭제 실패";return NextResponse.json({error:m},{status:m==="ADMIN_REQUIRED"?403:400});}
}
