"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { groups as mockGroups, weeklyQuiz as mockWeeklyQuiz } from "@/data/mock";
import { scoreQuiz } from "@/domain/scoring";
import type { Group, Person, PlayableQuestion, QuizDefinition, QuizResult, RankingPayload, ReviewQuestion, Screen } from "@/domain/types";

const STORAGE_KEY="weekly-cell-quiz-v08"; const USE_MOCK=process.env.NEXT_PUBLIC_USE_MOCK==="true";
type PlayKind="WEEKLY"|"SPECIAL"|"PRACTICE";
type Persisted={groupId:string;person:Person|null;answers:Array<number|null>;questionIndex:number;weeklyResult:QuizResult|null;sessionId:string|null};
type BootstrapQuiz={id:string;title:string;subtitle:string|null;life_date_range:string|null;bible_range:string|null;published_question_count:number|null;random_question_count:number|null;selection_mode:"FIXED"|"RANDOM"};

export function useQuizApp(){
 const [screen,setScreen]=useState<Screen>("select"); const [groups,setGroups]=useState<Group[]>(USE_MOCK?mockGroups:[]); const [groupId,setGroupId]=useState(USE_MOCK?mockGroups[0].id:""); const [person,setPerson]=useState<Person|null>(null);
 const [weeklyQuiz,setWeeklyQuiz]=useState<QuizDefinition>(mockWeeklyQuiz); const [quiz,setQuiz]=useState<QuizDefinition>(mockWeeklyQuiz); const [playKind,setPlayKind]=useState<PlayKind>("WEEKLY");
 const [questions,setQuestions]=useState<PlayableQuestion[]>(USE_MOCK?mockWeeklyQuiz.questions:[]); const [reviewQuestions,setReviewQuestions]=useState<ReviewQuestion[]>(USE_MOCK?mockWeeklyQuiz.questions:[]); const [answers,setAnswers]=useState<Array<number|null>>(()=>Array(USE_MOCK?mockWeeklyQuiz.questions.length:0).fill(null)); const [questionIndex,setQuestionIndex]=useState(0);
 const [result,setResult]=useState<QuizResult|null>(null); const [weeklyResult,setWeeklyResult]=useState<QuizResult|null>(null); const [sessionId,setSessionId]=useState<string|null>(null); const [weeklyRanking,setWeeklyRanking]=useState<RankingPayload|null>(null); const [monthlyRanking,setMonthlyRanking]=useState<RankingPayload|null>(null);
 const [stats,setStats]=useState<any>(null); const [archive,setArchive]=useState<any[]>([]); const [specials,setSpecials]=useState<any[]>([]); const [specialResult,setSpecialResult]=useState<any>(null); const [reviewAllowed,setReviewAllowed]=useState(true); const [reviewMessage,setReviewMessage]=useState<string|null>(null);
 const [hydrated,setHydrated]=useState(false); const [busy,setBusy]=useState(false); const [error,setError]=useState<string|null>(null); const restoredAnswers=useRef<Array<number|null>|null>(null);

 useEffect(()=>{async function hydrate(){try{if(!USE_MOCK){const response=await fetch("/api/bootstrap",{cache:"no-store"});const data=await response.json();if(!response.ok)throw new Error(data.error??"초기 데이터를 불러오지 못했습니다.");setGroups(data.groups);setGroupId((c:string)=>c||data.groups?.[0]?.id||"");const q:BootstrapQuiz|null=data.currentQuiz;if(q){const def={id:q.id,title:q.title,subtitle:q.subtitle??"지난주 말씀 돌아보기",lifeDateRange:q.life_date_range??"",bibleRange:q.bible_range??"",questions:[],publishedQuestionCount:q.published_question_count??q.random_question_count??undefined};setWeeklyQuiz(def);setQuiz(def);}}
 const raw=window.localStorage.getItem(STORAGE_KEY);if(raw){const saved=JSON.parse(raw) as Persisted;setGroupId(c=>saved.groupId||c);setPerson(saved.person??null);setQuestionIndex(saved.questionIndex??0);restoredAnswers.current=saved.answers??null;setWeeklyResult(saved.weeklyResult??null);setResult(saved.weeklyResult??null);setSessionId(saved.sessionId??null);if(saved.person)setScreen("home");}}
 catch(e){setError(e instanceof Error?e.message:"앱 데이터를 불러오지 못했습니다.");}finally{setHydrated(true);}}void hydrate();},[]);

 useEffect(()=>{if(!hydrated)return;window.localStorage.setItem(STORAGE_KEY,JSON.stringify({groupId,person,answers,questionIndex,weeklyResult,sessionId} satisfies Persisted));},[hydrated,groupId,person,answers,questionIndex,weeklyResult,sessionId]);

 useEffect(()=>{if(!person||USE_MOCK)return;async function loadPersonal(){try{const qs=encodeURIComponent(person!.id);const [a,b,c]=await Promise.all([fetch(`/api/me/stats?personId=${qs}`),fetch(`/api/me/archive?personId=${qs}`),fetch(`/api/special/status?personId=${qs}`)]);if(a.ok)setStats(await a.json());if(b.ok)setArchive((await b.json()).items??[]);if(c.ok)setSpecials((await c.json()).specials??[]);}catch{/* personal extras must not block quiz */}}void loadPersonal();},[person,weeklyResult]);

 useEffect(()=>{if(!person||!weeklyResult||USE_MOCK)return;async function loadRankings(){try{const [w,m]=await Promise.all([fetch(`/api/results/weekly?quizId=${encodeURIComponent(weeklyQuiz.id)}&personId=${encodeURIComponent(person!.id)}`),fetch(`/api/results/monthly?quizId=${encodeURIComponent(weeklyQuiz.id)}&personId=${encodeURIComponent(person!.id)}`)]);if(w.ok)setWeeklyRanking(await w.json());if(m.ok)setMonthlyRanking(await m.json());}catch{}}void loadRankings();},[person,weeklyResult,weeklyQuiz.id]);

 const group=useMemo(()=>groups.find(i=>i.id===groupId)??groups[0]??{id:"",name:"소속 셀 미지정",members:[]},[groups,groupId]); const question=questions[questionIndex]; const answeredCount=answers.filter(v=>v!==null).length; const missing=answers.map((a,i)=>a===null?i:null).filter((v):v is number=>v!==null); const runtimeQuiz=useMemo(()=>({...quiz,questions}),[quiz,questions]);
 function answer(choiceIndex:number){setAnswers(cur=>cur.map((v,i)=>i===questionIndex?choiceIndex:v));}

 async function startQuiz(mode:"OFFICIAL"|"PRACTICE"="OFFICIAL",override?:{id:string;title?:string;subtitle?:string;bibleRange?:string;lifeDateRange?:string;kind?:PlayKind}){
  if(!person)return;setBusy(true);setError(null);setSpecialResult(null);setReviewAllowed(true);setReviewMessage(null);try{const target=override?{...weeklyQuiz,id:override.id,title:override.title??"Quiz",subtitle:override.subtitle??"",bibleRange:override.bibleRange??"",lifeDateRange:override.lifeDateRange??"",questions:[]}:weeklyQuiz;setQuiz(target);setPlayKind(override?.kind??(mode==="PRACTICE"?"PRACTICE":"WEEKLY"));
   if(USE_MOCK){setQuiz(mockWeeklyQuiz);setQuestions(mockWeeklyQuiz.questions);setReviewQuestions(mockWeeklyQuiz.questions);setAnswers(Array(mockWeeklyQuiz.questions.length).fill(null));setQuestionIndex(0);setScreen("quiz");return;}
   const response=await fetch("/api/quiz/start",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({quizId:target.id,personId:person.id,mode})});const data=await response.json();if(!response.ok)throw new Error(data.error??"퀴즈를 시작하지 못했습니다.");setSessionId(data.session.id);setQuestions(data.questions);setQuiz(q=>({...q,questions:data.questions}));setAnswers(cur=>{if(data.resumed&&restoredAnswers.current?.length===data.questions.length)return restoredAnswers.current;if(data.resumed&&cur.length===data.questions.length)return cur;return Array(data.questions.length).fill(null);});setQuestionIndex(0);setScreen("quiz");
  }catch(e){setError(e instanceof Error?e.message:"퀴즈를 시작하지 못했습니다.");}finally{setBusy(false);}
 }

 async function submit(){setBusy(true);setError(null);try{if(USE_MOCK){const next=scoreQuiz(mockWeeklyQuiz.questions,answers);setResult(next);if(playKind==="WEEKLY")setWeeklyResult(next);setReviewQuestions(mockWeeklyQuiz.questions);setScreen("result");return next;}if(!sessionId)throw new Error("퀴즈 세션을 찾을 수 없습니다.");const payload=questions.map((q,i)=>({questionId:q.id,selectedIndex:answers[i]??null}));const response=await fetch("/api/quiz/submit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId,answers:payload})});const data=await response.json();if(!response.ok)throw new Error(data.error??"제출하지 못했습니다.");setResult(data.result);if(playKind==="WEEKLY")setWeeklyResult(data.result);setSpecialResult(data.special??null);setReviewAllowed(data.reviewAllowed!==false);setReviewMessage(data.reviewMessage??null);setReviewQuestions(data.reviewQuestions??[]);setScreen("result");return data.result as QuizResult;}catch(e){setError(e instanceof Error?e.message:"제출하지 못했습니다.");return null;}finally{setBusy(false);}}

 function goHome(){setQuiz(weeklyQuiz);setPlayKind("WEEKLY");setResult(weeklyResult);setSpecialResult(null);setQuestions(weeklyQuiz.questions);setScreen("home");}
 function resetPractice(){setAnswers(Array(questions.length).fill(null));setQuestionIndex(0);setResult(null);setSessionId(null);setScreen("intro");}
 function startSpecial(s:any){return startQuiz("OFFICIAL",{id:s.quizId,title:s.title,subtitle:"Special Quiz",kind:"SPECIAL"});}
 function startArchivedPractice(item:any){return startQuiz("PRACTICE",{id:item.quizId,title:item.title,subtitle:"지난 퀴즈 연습",bibleRange:item.bibleRange??"",lifeDateRange:item.lifeDateRange??"",kind:"PRACTICE"});}
 return {hydrated,busy,error,setError,screen,setScreen,groupId,setGroupId,group,person,setPerson,answers,answer,questionIndex,setQuestionIndex,question,answeredCount,missing,result,weeklyResult,sessionId,submit,startQuiz,resetPractice,quiz:runtimeQuiz,weeklyQuiz,groups,reviewQuestions,reviewAllowed,reviewMessage,weeklyRanking,monthlyRanking,stats,archive,specials,specialResult,playKind,goHome,startSpecial,startArchivedPractice};
}
